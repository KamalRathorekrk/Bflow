import 'package:bflow/app/bottom_nav_bar/bottom_navigation_pages.dart';
import 'package:bflow/app/claim_assessment/pages/details_page_sucess.dart';
import 'package:bflow/app/common_widget/common_action_button.dart';
import 'package:bflow/app/common_widget/common_app_bar.dart';
import 'package:bflow/app/common_widget/common_header.dart';
import 'package:bflow/app/common_widget/common_text_field_simple.dart';
import 'package:bflow/app/common_widget/common_text_widget.dart';
import 'package:bflow/utils/AppColors.dart';
import 'package:bflow/utils/AppImages.dart';
import 'package:bflow/utils/AppStrings.dart';
import 'package:bflow/utils/Dimens.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ClaimAssementStepFour extends StatefulWidget {
  @override
  _ClaimAssementStepFourState createState() => _ClaimAssementStepFourState();
}

class _ClaimAssementStepFourState extends State<ClaimAssementStepFour> {
  final _cardHolderNameController = TextEditingController();
  final _cardNumberController = TextEditingController();
  final _cvcController = TextEditingController();
  final _expController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset:false,
      appBar: CommonAppBar(
        text: AppStrings.claim_assessment,
      ),
      body: Container(
        child: Stack(
          children: [
            Container(
              child: Column(
                children: [
                  CommonHeader(step: 4,),
                  Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: Dimens.thirtyFive,
                        vertical: Dimens.twentyEight),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CommonTextWidget(

                          text: AppStrings.add_payment_card,
                          fontSize: Dimens.sixteen,
                          fontWeight: FontWeight.w600,
                          fontColor: AppColor.blackColor,
                        ),
                        SizedBox(
                          height: Dimens.twentyFive,
                        ),
                        CommonTextFieldSimple(
                          keyboardType: TextInputType.text,
                          textEditingController: _cardHolderNameController,
                          borderColor: AppColor.offWhite97Color,
                          hintText: AppStrings.cardholder_name,
                          color: AppColor.hintTextColor,
                        ),
                        CommonTextFieldSimple(
                          keyboardType: TextInputType.number,
                          textEditingController: _cardNumberController,
                          borderColor: AppColor.offWhite97Color,
                          hintText: AppStrings.card_number,
                          color: AppColor.hintTextColor,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: CommonTextFieldSimple(
                                keyboardType: TextInputType.number,
                                textEditingController: _cvcController,
                                borderColor: AppColor.offWhite97Color,
                                hintText: AppStrings.cvc,
                                color: AppColor.hintTextColor,
                              ),
                            ),
                            SizedBox(width: Dimens.ten,),
                            Expanded(
                              child: CommonTextFieldSimple(
                                keyboardType: TextInputType.number,
                                textEditingController: _expController,
                                borderColor: AppColor.offWhite97Color,
                                hintText: AppStrings.cvc,
                                color: AppColor.hintTextColor,
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          Positioned(
              bottom: Dimens.five,
              right: Dimens.five,
              left: Dimens.five,
              child: innerContainer(context))
          ],

        ),
      ),
    );
  }

  Widget innerContainer(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
          vertical: Dimens.twenty, horizontal: Dimens.thirty),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(right:Dimens.eight),
                child: SvgPicture.asset(AppImages.lock_security),
              ),
              CommonTextWidget(
                text: AppStrings.your_information_is_secure_and_protected,
                fontSize: Dimens.eleven,
                fontColor: AppColor.blackColor,
                fontStyle: FontStyle.italic,
              )
            ],
          ),
          SizedBox(
            height: Dimens.five,
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: Dimens.twenty),
            child: CommonActionButton(
              title: AppStrings.complete_delivery,
              onPressed: () {
                Navigator.pushReplacement(
                    context,
                    CupertinoPageRoute(
                        builder: (context) => BottomNavigationPage()));
              },
              borderRadius: Dimens.seven,
              backgroundColor: AppColor.primaryColor,
              width: double.maxFinite,
            ),
          ),
        ],
      ),
    );
  }

}
