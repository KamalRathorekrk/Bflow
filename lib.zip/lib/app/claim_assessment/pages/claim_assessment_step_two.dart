import 'dart:io';

import 'package:bflow/app/claim_assessment/pages/claim_assessment_step_three.dart';
import 'package:bflow/app/common_widget/common_action_button.dart';
import 'package:bflow/app/common_widget/common_app_bar.dart';
import 'package:bflow/app/common_widget/common_header.dart';
import 'package:bflow/app/common_widget/common_text_field_simple.dart';
import 'package:bflow/app/common_widget/common_text_widget.dart';
import 'package:bflow/app/common_widget/common_textfiled_multiline.dart';
import 'package:bflow/utils/AppColors.dart';
import 'package:bflow/utils/AppImages.dart';
import 'package:bflow/utils/AppStrings.dart';
import 'package:bflow/utils/Dimens.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class ClaimAssementStepTwo extends StatefulWidget {
  @override
  _ClaimAssementStepTwoState createState() => _ClaimAssementStepTwoState();
}

class _ClaimAssementStepTwoState extends State<ClaimAssementStepTwo> {
  final ImagePicker _picker = ImagePicker();
  List<XFile> imageList = [];
  final _nameController = TextEditingController();
  final _titleController = TextEditingController();
  final _reasonSignedController = TextEditingController();
  final _signedPhotoController = TextEditingController();
  final _addClaimNotesController = TextEditingController();

  @override
  void initState() {
    permissionAccess();
    super.initState();
  }

  Future<void> permissionAccess() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.camera,
      Permission.storage,
      Permission.photos
    ].request();
    print(statuses[Permission.camera]);
    print(statuses[Permission.storage]);
    if (await Permission.camera.request().isGranted) {
      print("Camera permission granted");
      // Either the permission was already granted before or the user just granted it.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: CommonAppBar(
          text: AppStrings.claim_assessment,
        ),
        body: SingleChildScrollView(
          controller: ScrollController(),
          child: Container(
            child: Column(children: [
              CommonHeader(
                step: 2,
              ),
              SizedBox(
                height: Dimens.twenty,
              ),
              innerConatiner(context),
            ]),
          ),
        ));
  }

  Widget innerConatiner(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
          vertical: Dimens.twenty, horizontal: Dimens.thirty),
      color: AppColor.offWhiteColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          dropDownWidget(),
          SizedBox(
            height: Dimens.thirty,
          ),
          CommonTextWidget(
            text: AppStrings.if_not_the_patient,
            fontSize: Dimens.fifteen,
            fontWeight: FontWeight.w500,
            fontColor: AppColor.blackColor,
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
          CommonTextFieldSimple(
            textEditingController: _nameController,
            borderColor: AppColor.offWhite97Color,
            hintText: AppStrings.name,
            color: AppColor.hintTextColor,
          ),
          CommonTextFieldSimple(
            textEditingController: _titleController,
            borderColor: AppColor.offWhite97Color,
            hintText: AppStrings.title,
            color: AppColor.hintTextColor,
          ),
          CommonTextFieldSimple(
            textEditingController: _reasonSignedController,
            borderColor: AppColor.offWhite97Color,
            hintText: AppStrings.reason_signed,
            color: AppColor.hintTextColor,
          ),
          CommonTextFieldSimple(
            textEditingController: _signedPhotoController,
            borderColor: AppColor.offWhite97Color,
            hintText: AppStrings.signed_phone,
            color: AppColor.hintTextColor,
          ),
          SizedBox(
            height: Dimens.ten,
          ),
          AttachPhotoWidget(),
          SizedBox(
            height: Dimens.twenty,
          ),
          imageContainer(),
          CommonTextFieldMultiLine(
            textEditingController: _addClaimNotesController,
            borderColor: AppColor.hintTextColor,
            color: AppColor.hintTextColor,
            hintText: AppStrings.add_claim_notes,
            maxLines: 8,
            minLines: 7,
          ),
          SizedBox(
            height: Dimens.ten,
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: Dimens.twenty),
            child: CommonActionButton(
              title: AppStrings.next,
              onPressed: () {
                Navigator.push(
                    context,
                    CupertinoPageRoute(
                        builder: (context) => ClaimAssementStepThree()));
              },
              borderRadius: Dimens.seven,
              backgroundColor: AppColor.primaryColor,
              width: double.maxFinite,
            ),
          ),
        ],
      ),
    );
  }

  Widget dropDownWidget() {
    return Container(
      child: DropdownButtonFormField(
        hint: CommonTextWidget(
          text: AppStrings.who_received,
          fontSize: Dimens.fifteen,
          fontWeight: FontWeight.w600,
          fontColor: AppColor.blackColor,
        ),
        items: [
          'Patient',
          'Family Member',
          'Driver',
          'Care Taker',
        ].map((label) {
          return DropdownMenuItem(
            child: Container(
              child: CommonTextWidget(
                text: label.toString(),
                fontSize: Dimens.forteen,
                fontColor: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                textAlignment: TextAlign.left,
              ),
            ),
            value: label,
          );
        }).toList(),
        dropdownColor: AppColor.whiteColor,
        decoration: InputDecoration(
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide:
                BorderSide(color: AppColor.offWhite97Color, width: Dimens.one),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide:
                BorderSide(color: AppColor.offWhite97Color, width: Dimens.one),
          ),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(
                  color: AppColor.offWhite97Color, width: Dimens.one)),
        ),
        onChanged: (value) {
          setState(() {});
        },
      ),
    );
  }

  Widget AttachPhotoWidget() {
    return InkWell(
      onTap: () async {
        showSelectionDialog(context);
      },
      child: Container(
        padding: EdgeInsets.all(Dimens.sixteen),
        decoration: BoxDecoration(
          border: Border.all(color: AppColor.primaryColor),
          borderRadius: BorderRadius.circular(Dimens.ten),
          color: AppColor.offWhiteColor,
        ),
        width: double.maxFinite,
        child: Center(
          child: Text(
            AppStrings.attach_photo.toUpperCase(),
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: Dimens.sixteen,
                fontFamily: AppStrings.fontFamily,
                color: AppColor.primaryColor),
          ),
        ),
      ),
    );
  }

  void showSelectionDialog(BuildContext context) async {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text(
                "From where do you want to take the photo?",
                style: TextStyle(fontSize: Dimens.forteen),
              ),
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    GestureDetector(
                      child: Text(
                        "Gallery",
                        style: TextStyle(fontSize: Dimens.twelve),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        _openGallery(context);
                      },
                    ),
                    Padding(padding: EdgeInsets.all(8.0)),
                    GestureDetector(
                      child: Text(
                        "Camera",
                        style: TextStyle(fontSize: Dimens.twelve),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        _openCamera(context);
                      },
                    )
                  ],
                ),
              ));
        });
  }

  _openGallery(BuildContext context) async {
    XFile? image = await _picker.pickImage(source: ImageSource.gallery);

    setState(() {
      if(image!=null){
        imageList.add(image);
      }
    });
    setState(() {});
    Navigator.of(context).pop();
  }

  _openCamera(BuildContext context) async {
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);

    print(image!.path);
    setState(() {
      if(image!=null){
        imageList.add(image);
      }
    });
    Navigator.of(context).pop();
  }

  Widget imageContainer() {
    if (imageList.length == 0) return Container();
    return Container(
      height: Dimens.oneForty,
      child: ListView.builder(
          shrinkWrap: true,
          // physics: ClampingScrollPhysics(),
          scrollDirection: Axis.horizontal,
          itemCount: imageList.length,
          itemBuilder: (context, position) {
            return Container(
                height: Dimens.hundred,
                width: Dimens.hundred,
                margin: EdgeInsets.only(
                  left: Dimens.ten,
                ),
                child: Stack(children: [
                  Container(
                    margin: EdgeInsets.only(top: Dimens.ten),
                    decoration: BoxDecoration(
                        border: Border.all(color: AppColor.hintColor)),
                    height: Dimens.hundred,
                    width: Dimens.hundred,
                    child: Image.file(
                      File(imageList[position].path),
                      fit: BoxFit.fill,
                    ),
                  ),
                  Positioned(
                      top: Dimens.five,
                      right: 0,
                      child: InkWell(
                          onTap: () {
                            imageList.removeAt(position);
                            setState(() {});
                          },
                          child: SvgPicture.asset(AppImages.cross))),
                ]));
          }),
    );
  }
}
