import 'package:bflow/app/common_widget/snackbar/utils.dart';
import 'package:bflow/app/login/model/demo_model.dart';
import 'package:bflow/app/login/model/login_model.dart';
import 'package:bflow/network/api_repository.dart';
import 'package:bflow/utils/AppStrings.dart';
import 'package:flutter/cupertino.dart';
import 'package:rxdart/rxdart.dart';

class LoginBlock {
  final _responseSink = BehaviorSubject<bool>();

  Stream<bool> get responseStream => _responseSink.stream;
  ApiRepository apiRepository = ApiRepository();
  LoginModel? loginModel;
  DemoModel? demoModel;

  // Future<dynamic> loginUpApiCall(
  //     {required BuildContext context,
  //       String? userName,
  //       String? password,
  //       String? corporateId,
  //       }) async {
  //   loginModel = LoginModel(corporateId: corporateId,password: password,userName: userName);
  //   apiRepository
  //       .signup(context: context, loginModel: loginModel)
  //       .then((onResponse) {
  //     print("onResponse $onResponse");
  //     if (onResponse != null)
  //       _responseSink.add(true);
  //     else
  //       SnackBarUtils.showErrorSnackBar(AppStrings.something_went_wrong, context);
  //   }).catchError((onError) {
  //     _responseSink.add(false);
  //     SnackBarUtils.showErrorSnackBar(AppStrings.something_went_wrong, context);
  //   });
  Future<dynamic> loginUpApiCall({
    required BuildContext context,
  }) async {
    apiRepository.signup(context: context).then((onResponse) {
      if (onResponse != null) {
        print("onResponse : ${onResponse}");
        DemoModel demoModel=DemoModel.fromJson(onResponse);


        _responseSink.add(true);
        return onResponse;
      } else {
        SnackBarUtils.showErrorSnackBar(
            AppStrings.something_went_wrong, context);
        return onResponse;
      }
    }).catchError((onError) {
      _responseSink.add(false);
      SnackBarUtils.showErrorSnackBar(AppStrings.something_went_wrong, context);
    });
  }
}
