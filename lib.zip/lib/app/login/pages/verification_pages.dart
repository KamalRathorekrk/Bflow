import 'package:bflow/app/bottom_nav_bar/bottom_navigation_pages.dart';
import 'package:bflow/app/common_widget/common_action_button.dart';
import 'package:bflow/app/common_widget/common_text_underLine_widget.dart';
import 'package:bflow/app/common_widget/common_text_widget.dart';
import 'package:bflow/app/common_widget/common_textfield.dart';
import 'package:bflow/app/common_widget/snackbar/utils.dart';
import 'package:bflow/app/login/pages/login.dart';
import 'package:bflow/app/today_route/pages/todays_route.dart';
import 'package:bflow/utils/AppColors.dart';
import 'package:bflow/utils/AppImages.dart';
import 'package:bflow/utils/AppStrings.dart';
import 'package:bflow/utils/CommonUtils.dart';
import 'package:bflow/utils/Dimens.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:pinput/pin_put/pin_put.dart';

class Verification extends StatefulWidget {
  @override
  _VerificationState createState() => _VerificationState();
}

class _VerificationState extends State<Verification> {
  final corporateIdController = TextEditingController();
  final userNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          color: AppColor.backgroundColor,
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.symmetric(
              vertical: Dimens.thirty, horizontal: Dimens.thirty),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: Dimens.twenty,),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: SvgPicture.asset(
                  AppImages.ic_back_small,
                  color: AppColor.whiteColor,
                ),
              ),
              SizedBox(
                height: Dimens.twenty,
              ),
              CommonTextWidget(
                text: AppStrings.verification,
                fontSize: Dimens.twentyNine,
                fontWeight: FontWeight.w700,
                fontColor: AppColor.whiteColor,
              ),
              SizedBox(
                height: Dimens.ten,
              ),
              CommonTextWidget(
                text: AppStrings.otp_send,
                fontSize: Dimens.forteen,
                fontWeight: FontWeight.w500,
                fontColor: AppColor.whiteColor,
                height: 1.5,
              ),
              SizedBox(
                height: Dimens.thirty,
              ),
              PinPut(
                eachFieldConstraints: BoxConstraints(
                    minHeight: Dimens.sixtyFour, minWidth: Dimens.sixtyFour),
                fieldsCount: 4,
                focusNode: FocusNode(),
                submittedFieldDecoration: BoxDecoration(
                  border: Border.all(color: AppColor.whiteColor),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                selectedFieldDecoration: BoxDecoration(
                  border: Border.all(color: AppColor.whiteColor),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                followingFieldDecoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  border: Border.all(
                    color: AppColor.whiteColor,
                  ),
                ),
              ),
              SizedBox(
                height: Dimens.thirty,
              ),
              CommonActionButton(
                title: AppStrings.submit,
                onPressed: () {
                  Navigator.push(
                      context,
                      CupertinoPageRoute(
                          builder: (context) => BottomNavigationPage()));
                  // if(formValidation(context)) {
                  //   Navigator.push(context,
                  //       CupertinoPageRoute(builder: (context) => TodaysRoute()));
                  // }
                },
                borderRadius: Dimens.ten,
                backgroundColor: AppColor.primaryColor,
                width: double.maxFinite,
                shadowColor: AppColor.backgroundColor,
              ),
              SizedBox(height: Dimens.thirty),
              Center(
                child: CommonTextUnderLineWidget(
                  textDecoration: TextDecoration.underline,
                  text: AppStrings.resend_otp,
                  fontSize: Dimens.fifteen,
                  fontWeight: FontWeight.w500,
                  fontColor: AppColor.whiteColor,
                ),
              ),
            ],
          )),
    );
  }
}
