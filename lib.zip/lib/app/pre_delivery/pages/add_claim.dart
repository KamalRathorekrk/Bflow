import 'package:bflow/app/common_widget/common_action_button.dart';
import 'package:bflow/app/common_widget/common_app_bar.dart';
import 'package:bflow/app/common_widget/common_text_widget.dart';
import 'package:bflow/app/common_widget/common_textfiled_multiline.dart';
import 'package:bflow/app/routes_activity_list/pages/routes_activity_list.dart';
import 'package:bflow/utils/AppColors.dart';
import 'package:bflow/utils/AppImages.dart';
import 'package:bflow/utils/AppStrings.dart';
import 'package:bflow/utils/Dimens.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maps_launcher/maps_launcher.dart';

class AddClaim extends StatefulWidget {
  @override
  _AddClaimState createState() => _AddClaimState();
}

class _AddClaimState extends State<AddClaim> {
  final _addClaimNotesController = TextEditingController();
  List<String> checkListItem = [
    AppStrings.pick_equipment,
    AppStrings.complete_equipment_inspection_log,
    AppStrings.print_delivery_ticket_and_delivery_packet,
    AppStrings.verify_delivery_address_and_time,
  ];
  List<bool> _isCheckedClaim = [];
  @override
  void initState() {
    _isCheckedClaim = List<bool>.filled(checkListItem.length, false);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: AppColor.offWhiteColor));
    return Scaffold(
      appBar: CommonAppBar(
        text: "Claim: #2325",
      ),
      body: SingleChildScrollView(
        controller: ScrollController(),
        child: Container(
          padding: EdgeInsets.symmetric(
              horizontal: Dimens.twenty, vertical: Dimens.ten),
          color: AppColor.offWhiteColor,

          // width: double.infinity,
          child: Stack(
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Column(
                  children: [
                    PatientDetailsContainer(),
                    SizedBox(
                      height: Dimens.twenty,
                    ),
                    DetailsContainer(),
                    SizedBox(
                      height: Dimens.twenty,
                    ),
                    checkListWidget(),
                    SizedBox(
                      height: Dimens.twenty,
                    ),
                    CommonTextFieldMultiLine(
                      textEditingController: _addClaimNotesController,
                      borderColor: AppColor.hintTextColor,
                      color: AppColor.hintTextColor,
                      hintText: AppStrings.add_claim_notes,
                      maxLines: 8,
                      minLines: 7,
                    ),
                    SizedBox(
                      height: Dimens.twenty,
                    ),
                    CommonActionButton(
                      title: AppStrings.submit_and_schedule_delivery,
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      borderRadius: Dimens.seven,
                      backgroundColor: AppColor.primaryColor,
                      width: double.maxFinite,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget PatientDetailsContainer() {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: Dimens.fifteen, vertical: Dimens.ten),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimens.ten),
        boxShadow: [
          BoxShadow(color: AppColor.offWhite17Color, blurRadius: 5.0)
        ],
        color: AppColor.whiteColor,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: Dimens.fifteen,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonTextWidget(
                    text: AppStrings.patient_name,
                    fontSize: Dimens.thrteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                  SizedBox(
                    height: Dimens.eight,
                  ),
                  CommonTextWidget(
                    text: "Mary Beth",
                    fontSize: Dimens.forteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w500,
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsets.only(right: Dimens.ten),
                child: SvgPicture.asset(AppImages.call),
              )
            ],
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
          Divider(
            thickness: 1,
            height: Dimens.two,
            color: AppColor.offWhite17Color,
          ),
          SizedBox(height: Dimens.twenty),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonTextWidget(
                    text: AppStrings.delivery_address,
                    fontSize: Dimens.thrteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                  SizedBox(
                    height: Dimens.eight,
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(right: Dimens.four),
                        child: SvgPicture.asset(AppImages.location),
                      ),
                      CommonTextWidget(
                        text: "1700 Cheddar Ln, Tullahoma, TN",
                        fontSize: Dimens.forteen,
                        fontColor: AppColor.blackColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: Dimens.twenty),
          Divider(
            thickness: 1,
            height: Dimens.two,
            color: AppColor.offWhite17Color,
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonTextWidget(
                    text: AppStrings.zip_code,
                    fontSize: Dimens.thrteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                  SizedBox(
                    height: Dimens.eight,
                  ),
                  CommonTextWidget(
                    text: "134402",
                    fontSize: Dimens.forteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w500,
                  ),
                ],
              ),
              InkWell(
                onTap: () async {
                  print("----");
                  await MapsLauncher.launchCoordinates(
                      37.4220041, -122.0862462, 'Google Headquarters are here');
                },
                child: Padding(
                  padding: EdgeInsets.only(right: Dimens.ten),
                  child: Text(AppStrings.view_on_map,
                      style: TextStyle(
                        shadows: [
                          Shadow(
                              color: AppColor.backgroundColor,
                              offset: Offset(0, -2))
                        ],
                        color: Colors.transparent,
                        decoration: TextDecoration.underline,
                        decorationColor: AppColor.backgroundColor,
                        fontWeight: FontWeight.w600,
                        fontSize: Dimens.thrteen,
                      )),
                ),
              ),
            ],
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
        ],
      ),
    );
  }

  Widget DetailsContainer() {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: Dimens.fifteen, vertical: Dimens.ten),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimens.ten),
        boxShadow: [
          BoxShadow(color: AppColor.offWhite17Color, blurRadius: 5.0)
        ],
        color: AppColor.whiteColor,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: Dimens.fifteen,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonTextWidget(
                    text: AppStrings.description,
                    fontSize: Dimens.thrteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                  SizedBox(
                    height: Dimens.eight,
                  ),
                  CommonTextWidget(
                    text: "Light Wheelchair",
                    fontSize: Dimens.forteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w500,
                  ),
                ],
              ),
            ],
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
          Divider(
            thickness: 1,
            height: Dimens.two,
            color: AppColor.offWhite17Color,
          ),
          SizedBox(height: Dimens.twenty),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonTextWidget(
                    text: AppStrings.select_equipment,
                    fontSize: Dimens.thrteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                  dropDownWidget(),
                ],
              ),
            ],
          ),
          Divider(
            thickness: 1,
            height: Dimens.two,
            color: AppColor.offWhite17Color,
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonTextWidget(
                    text: AppStrings.select_model,
                    fontSize: Dimens.thrteen,
                    fontColor: AppColor.blackColor,
                    fontWeight: FontWeight.w400,
                  ),
                  dropDownWidget(),
                ],
              ),
            ],
          ),
          Divider(
            thickness: 1,
            height: Dimens.two,
            color: AppColor.offWhite17Color,
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CommonTextWidget(
                text: AppStrings.date_time_of_delivery,
                fontSize: Dimens.thrteen,
                fontColor: AppColor.blackColor,
                fontWeight: FontWeight.w400,
              ),
              InkWell(
                onTap: () {
                  print("-----");
                  twoButtonCommonDialog(context);
                },
                child: Padding(
                  padding: EdgeInsets.only(right: Dimens.four),
                  child: SvgPicture.asset(
                    AppImages.calender,
                    width: Dimens.twentyFour,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
            height: Dimens.twenty,
          ),
        ],
      ),
    );
  }


  Widget checkListWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CommonTextWidget(
          text: AppStrings.complete_checklist,
          fontSize: Dimens.forteen,
          fontWeight: FontWeight.w600,
          fontColor: AppColor.blackColor,
        ),
        Padding(
          padding: EdgeInsets.symmetric(vertical: Dimens.fifteen),
          child: ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              padding: EdgeInsets.zero,
              itemCount: checkListItem.length,
              itemBuilder: (context, position) {
                return GestureDetector(
                  onTap: (){
                    setState(() {
                      _isCheckedClaim[position] = !_isCheckedClaim[position];
                    });
                  },
                    child: rowElement(valueString: checkListItem[position],isChecked: _isCheckedClaim[position]));
              }),
        ),
      ],
    );
  }

  Widget rowElement({String? valueString, bool? isChecked}) {
    String icon;
    if (isChecked == true)
      icon = AppImages.checkmark;
    else
      icon = AppImages.check;
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(
              top: Dimens.eight, right: Dimens.twelve, bottom: Dimens.eight),
          child: SvgPicture.asset(icon),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: Dimens.five),
            child: CommonTextWidget(
                height: 1.3,
                text: valueString!,
                fontSize: Dimens.forteen,
                fontWeight: FontWeight.w400,
                fontColor: AppColor.blackColor),
          ),
        ),
      ],
    );
  }


  void twoButtonCommonDialog(BuildContext context) async {
    DateTime? tempPickedDate;
    return showDialog(
      context: context,
      // barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(Dimens.fifteen))),
          title: CommonTextWidget(
            text: AppStrings.set_date_and_time_of_delivery,
            fontSize: Dimens.sixteen,
            textAlignment: TextAlign.center,
            fontWeight: FontWeight.w500,
            fontColor: AppColor.blackColor,
          ),
          content: Container(
            // color: AppColor.redColor,
            height: MediaQuery.of(context).size.height * 0.45,
            child: Column(
              children: [
                Container(
                  height: Dimens.twoHundred,
                  child: CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.dateAndTime,
                    onDateTimeChanged: (DateTime dateTime) {
                      print("---$dateTime---");
                      tempPickedDate = dateTime;
                    },
                  ),
                ),
                SizedBox(
                  height: Dimens.twenty,
                ),
                CommonTextWidget(
                  text: "Wed May 19, 2021",
                  fontSize: Dimens.twenty,
                  fontWeight: FontWeight.w600,
                  fontColor: AppColor.blackColor,
                ),
                SizedBox(
                  height: Dimens.ten,
                ),
                CommonTextWidget(
                  text: "12:00 PM",
                  fontSize: Dimens.seventeen,
                  fontWeight: FontWeight.w500,
                  fontColor: AppColor.blackColor,
                ),
              ],
            ),
          ),
          actions: [
            Column(
              children: [
                Divider(
                  thickness: Dimens.one,
                  height: Dimens.one,
                  color: AppColor.offWhite17Color,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: CommonTextWidget(
                        text: AppStrings.cancel.toUpperCase(),
                        fontSize: Dimens.seventeen,
                        fontWeight: FontWeight.w600,
                        fontColor: AppColor.redColor,
                      ),
                    ),
                    Container(
                      width: Dimens.one,
                      height: Dimens.fifty,
                      color: AppColor.offWhite17Color,
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: CommonTextWidget(
                        text: AppStrings.ok.toUpperCase(),
                        fontSize: Dimens.seventeen,
                        fontWeight: FontWeight.w600,
                        fontColor: AppColor.blueColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  Widget dropDownWidget() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.8,
      child: DropdownButtonFormField(
        decoration: InputDecoration(
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.white))),
        hint: CommonTextWidget(
          text: "Ventilator",
          fontSize: Dimens.forteen,
          fontWeight: FontWeight.w500,
          fontColor: AppColor.blackColor,
        ),
        items: ['Ventilator', 'Infusion Pump', 'Syringe Pump', 'Defibrillators']
            .map((label) {
          return DropdownMenuItem(
            child: Container(
              color: AppColor.whiteColor,
              child: CommonTextWidget(
                text: label.toString(),
                fontSize: Dimens.forteen,
                fontColor: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                textAlignment: TextAlign.left,
              ),
            ),
            value: label,
          );
        }).toList(),
        dropdownColor: AppColor.whiteColor,
        onChanged: (value) {
          setState(() {});
        },
      ),
    );
  }
}
