import 'package:bflow/app/common_widget/common_text_widget.dart';
import 'package:bflow/app/pre_delivery/pages/add_claim.dart';
import 'package:bflow/app/today_route/model/datamodel.dart';
import 'package:bflow/utils/AppColors.dart';
import 'package:bflow/utils/AppStrings.dart';
import 'package:bflow/utils/Dimens.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class PreDelivery extends StatefulWidget {
  @override
  _PreDeliveryState createState() => _PreDeliveryState();
}

class _PreDeliveryState extends State<PreDelivery> {
  List<DataModel> itemList = [];

  void initState() {
    itemList.add(DataModel(
        id: "#53434",
        location: "1700 Cheddar Ln ,TN",
        name: "Skywalker Diana",
        time: "3:10PM",
        check: true));
    itemList.add(DataModel(
        id: "#77434",
        location: "3400 Cheddar Ln ,TN",
        name: "Albert Smith",
        time: "",
        check: false));
    itemList.add(DataModel(
        id: "#88434",
        location: "4400 Cheddar Ln ,TN",
        name: "Johnson Park",
        time: "",
        check: false));
    itemList
      ..add(DataModel(
          id: "#99434",
          location: "6700 Cheddar Ln ,TN",
          name: "Penny Rick",
          time: "",
          check: false))
      ..add(DataModel(
          id: "#55434",
          location: "6700 Cheddar Ln ,TN",
          name: "Penny Rick",
          time: "",
          check: false));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        backgroundColor: AppColor.backgroundColor,
        title: CommonTextWidget(
          text: AppStrings.pre_delivery,
          fontSize: Dimens.eighteen,
          fontColor: AppColor.whiteColor,
          fontWeight: FontWeight.w600,
        ),
      ),
      body: SingleChildScrollView(
        controller: ScrollController(),
        child: Container(
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.symmetric(
              vertical: Dimens.thirty, horizontal: Dimens.twentyFive),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListData(context),
            ],
          ),
        ),
      ),
      // bottomNavigationBar: BottomNavigationPage(),
    );
  }

  Widget CommonItemWidget(
      {index,
      String? id,
      String? location,
      String? name,
      String? time,
      bool? status}) {
    return Container(
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 2,
                margin: EdgeInsets.only(bottom: Dimens.five),
                height: Dimens.five,
                //color: AppColor.blackColor,
              ),
              CommonTextWidget(
                text: "0$index",
                fontSize: Dimens.fifteen,
                fontWeight: FontWeight.w500,
                fontColor: AppColor.backgroundColor,
              ),
              Container(
                width: 2,
                margin: EdgeInsets.only(top: Dimens.five),
                height: Dimens.fortyFive,
                color: AppColor.blackColor,
              ),
            ],
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 18.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonTextWidget(
                    text: "Claim :$id",
                    fontSize: Dimens.fifteen,
                    fontWeight: FontWeight.w600,
                    fontColor: AppColor.blueColor,
                  ),
                  SizedBox(
                    height: Dimens.seven,
                  ),
                  Row(
                    children: [
                      Icon(
                        Icons.location_on_outlined,
                        size: 16,
                      ),
                      CommonTextWidget(
                        text: location!,
                        fontSize: Dimens.forteen,
                        fontWeight: FontWeight.w500,
                        fontColor: AppColor.blackColor,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: Dimens.seven,
                  ),
                  CommonTextWidget(
                    text: name!,
                    fontSize: Dimens.thrteen,
                    fontWeight: FontWeight.w400,
                    fontColor: AppColor.blackColor,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget ListData(BuildContext context) {
    return ListView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        padding: EdgeInsets.zero,
        itemCount: itemList.length,
        itemBuilder: (context, position) {
          return GestureDetector(
            onTap: () {
              Navigator.push(context,
                  CupertinoPageRoute(builder: (context) => AddClaim()));
            },
            child: CommonItemWidget(
                index: position + 1,
                id: itemList[position].id,
                location: itemList[position].location,
                name: itemList[position].name,
                time: itemList[position].time,
                status: itemList[position].check),
          );
        });
  }
}
