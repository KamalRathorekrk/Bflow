import 'package:bflow/app/common_widget/common_action_button.dart';
import 'package:bflow/app/common_widget/common_app_bar.dart';
import 'package:bflow/app/common_widget/common_text_field_simple.dart';
import 'package:bflow/utils/AppColors.dart';
import 'package:bflow/utils/AppStrings.dart';
import 'package:bflow/utils/Dimens.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ChangePassword extends StatefulWidget {
  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  final currentPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: CommonAppBar(
        text: AppStrings.change_password,
      ),
      body: SingleChildScrollView(
        controller: ScrollController(),
        child: Container(
          color:AppColor.offWhiteColor,
          padding: EdgeInsets.symmetric(
              vertical: Dimens.twentyNine, horizontal: Dimens.thirty),
          child: Column(
            children: [
              SizedBox(height: Dimens.forty,),
              CommonTextFieldSimple(
                textEditingController: currentPasswordController,
                hintText: AppStrings.change_password,
                color: AppColor.offWhite66Color,
                borderColor: AppColor.offWhite97Color,
              ),
              CommonTextFieldSimple(
                textEditingController: newPasswordController,
                hintText: AppStrings.new_password,
                color: AppColor.offWhite66Color,
                borderColor: AppColor.offWhite97Color,
              ),
              CommonTextFieldSimple(
                textEditingController: confirmPasswordController,
                hintText: AppStrings.confirm_new_password,
                color: AppColor.offWhite66Color,
                borderColor: AppColor.offWhite97Color,
              ),
              SizedBox(height: Dimens.forty,),
              CommonActionButton(
                title: AppStrings.submit,
                onPressed: () {
                  Navigator.pop(context);
                },
                borderRadius: Dimens.seven,
                backgroundColor: AppColor.primaryColor,
                width: double.maxFinite,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
