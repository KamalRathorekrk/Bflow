import 'dart:io';

import 'package:bflow/app/login/model/demo_model.dart';
import 'package:bflow/network/exception_handling/exception_handling.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import 'common_api_end_points.dart';

class ApiRepository {
  Dio? _dio;
  BaseOptions? options;

  ApiRepository() {
    options = BaseOptions(
      connectTimeout: 20000,
      receiveTimeout: 20000,
    );
    _dio = Dio(options);
    _dio!.options.baseUrl = ApiEndPoints.base_url;
    _dio!.options.headers['content-Type'] = 'application/json';
  }

  Future<dynamic> signup({BuildContext? context}) async {
    try {
      final response = await _dio!.get("https://catfact.ninja/fact");
      print('---- Response Data :---${response.statusMessage}');
      print('---- Response Data :---${response.statusCode}');
      // print('---- Response Data :---${response.headers}');
      if (response.statusCode == 200)
        return response.data;
      else
        return null;
    } on SocketException {
      throw NoInternetException("SocketException");
    } on HttpException {
      throw NoServiceFoundException("HttpException");
    } on FormatException {
      throw InvalidFormatException("FormatException");
    } catch (e) {
      print("UnknownException ${e.toString()}");
      throw UnknownException(e.toString());
    }
  }
//
// String getUrl({String? endPoint}) {
//   print("api_url ${ApiEndPoints.base_url}$endPoint?apikey=${ApiEndPoints.apikey}");
//   return "${ApiEndPoints.base_url}$endPoint?apikey=${ApiEndPoints.apikey}";
// }

}
