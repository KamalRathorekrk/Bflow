class ApiEndPoints {
  static const String base_url = "https://mvapi-8de60.web.app/";
  static const String apikey = "mYxNjg3MGY5N2VmOTBkYjN";
  static const String post_api_usernz = "usernz";
}
