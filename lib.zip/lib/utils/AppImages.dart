class AppImages {
  static String bg = 'assets/images/bg.png';
  static String coperate_id = 'assets/images/coperate_id.svg';
  static String drop_down = 'assets/images/drop_down.svg';
  static String edit = 'assets/images/edit.svg';
  static String eye = 'assets/images/eye.svg';
  static String eye_closed = 'assets/images/eye_closed.svg';
  static String checkmark = 'assets/images/checkmark.svg';
  static String location = 'assets/images/location.svg';
  static String lock = 'assets/images/lock.svg';
  static String pre = 'assets/images/pre.svg';
  static String pre_select = 'assets/images/pre_select.svg';
  static String profile = 'assets/images/profile.svg';
  static String route_list = 'assets/images/route_list.svg';
  static String route_select = 'assets/images/route_select.svg';
  static String settings = 'assets/images/settings.svg';
  static String settings_select = 'assets/images/settings_select.svg';
  static String tick = 'assets/images/tick.svg';
  static String tick_new = 'assets/images/tick_new.svg';
  static String today_route = 'assets/images/today_route.svg';
  static String today_select = 'assets/images/today_select.svg';
  static String bflow_logo = 'assets/images/bflow_logo.png';
  static String back_arrow = 'assets/images/back_arrow.svg';
  static String call = 'assets/images/call.svg';
  static String check = 'assets/images/check.svg';
  static String calender = 'assets/images/calender.svg';
  static String lock_security = 'assets/images/lock_security.svg';
  static String signature = 'assets/images/Oprah-Winfrey-Signature-1.png';
  static String cross = 'assets/images/cross.svg';
  static String ic_back_small = 'assets/images/ic_back_small.svg';
  static String bflow_white = 'assets/images/bflow_white.png';


}